import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'employee-content',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  showEdit = false;
  EditEmp(){
  this.showEdit = true
  }

  UpdateEmp(){
    this.showEdit = false
  }
  employeeData = {
   empId : "123",
   firstName:  "George",
   lastName : "Harry",
   salary : "10000" ,
   dob : "01/10/1980",
   email : "d@gmail.com"
   
 }

  constructor() { }

  ngOnInit(): void {
  }

}
